# OS PRO — Elétrica & Software

**Projeto Android 1.0.0, pronto para compilação via GitHub Actions.** Este pacote é o **código-fonte**, não um APK já compilado. O fluxo automático produz um APK de teste instalável (`app-debug.apk`) quando o código é enviado a um repositório GitHub.

## Funcionalidades implementadas

- **Ordens de serviço:** elétrica, software, redes/TI, cliente e técnico, status, prioridade, abertura, previsão, descrição, diagnóstico, execução, materiais e valores. Número de OS sequencial local.
- **Cadastros:** clientes e usuários/equipe técnica, com edição e bloqueio de exclusão quando vinculados a uma OS.
- **Financeiro:** receitas, despesas, pagamento, vinculação opcional à OS, saldos e histórico.
- **Assinatura presencial:** dois espaços independentes (cliente e técnico), assinatura por dedo/caneta com Pointer Events e dimensionamento de tela correto. Ao salvar, **Salvar fica desabilitado e Limpar permanece habilitado**. Armazena data/hora e coordenadas quando autorizadas pelo aparelho.
- **Assinatura por link:** servidor Node.js separado, acessível por HTTPS, com links únicos de 7 dias, aceite, assinatura na tela do cliente, hora oficial do servidor, geolocalização mediante permissão e registro de auditoria. O app compartilha por WhatsApp/SMS/e-mail usando o menu de compartilhamento do Android; não envia SMS de forma automática.
- **PDF A4 nativo Android:** gera documento com empresa, OS, cliente, técnico, serviço, valores, assinaturas, datas/horas, coordenadas, fotos. Salva em `Downloads/OS-Pro`, com botão de compartilhamento. Só após **salvar com sucesso** o PDF final o app arquiva a OS e libera uma **nova OS limpa**.
- **GOV.BR:** exporta PDF da OS sem finalizar, abre `https://assinador.iti.br/` no navegador do dispositivo para assinatura **externa e oficial**, e importa o PDF assinado sem reescrever seu conteúdo. Importar arquiva a OS e inicia nova. **Não verifica criptograficamente a assinatura GOV.BR**: utilize `https://validar.iti.gov.br/` para essa finalidade. **Não inclui integração direta com a API GOV.BR**, que exige habilitação institucional.
- **Evidências:** câmera/galeria Android e imagens locais no IndexedDB, incluídas no PDF.
- **Backup:** exportar/importar JSON com fotos. Alto contraste e tamanho maior de fonte.

## Como gerar o APK no GitHub — inclusive pelo tablet

1. Crie um repositório novo no GitHub, por exemplo `ospro-eletrica-software`, **vazio** (sem README automático, se possível).
2. Extraia `OSPro-Eletrica-Software-Fonte.zip` no tablet ou computador. Envie o **conteúdo da pasta extraída**, incluindo `.github/workflows/build-apk.yml`, para o repositório. Se usar `git` no Termux ou computador:

```bash
cd ospro-eletrica-software
git init -b main
git add .
git commit -m "Aplicativo OS Pro Android"
git remote add origin https://github.com/SEU_USUARIO/ospro-eletrica-software.git
git push -u origin main
```

3. No GitHub: **Actions → Gerar APK Android → Run workflow** (também executa automaticamente a cada push na branch `main`).
4. Abra o job concluído e baixe o artefato **OS-Pro-Eletrica-Software-APK**. Extraia o ZIP do artefato; o arquivo `app-debug.apk` está dentro dele.
5. Instale esse APK no tablet ou celular Android. Se solicitado pelo Android, habilite **Instalar apps desconhecidos** apenas para o aplicativo de arquivos usado.

> O APK é uma **compilação de teste**, assinada pela chave debug do GitHub runner. Para publicar na Play Store ou distribuir atualizações estáveis, é necessário criar e guardar sua **chave de assinatura release** e configurar a etapa de publicação. Cada novo build debug em runner distinto pode usar uma chave diferente, exigindo desinstalar o anterior (com backup dos dados primeiro).

### Requisitos da build

- JDK 17, Android SDK 35 e Gradle 8.10.2 (instalados pelo GitHub Actions).
- Aplicativo com Kotlin/Android WebView seguro (`WebViewAssetLoader`); conteúdo HTML, CSS e JS totalmente local.
- Android 8.0 (API 26) ou superior. Testar principalmente em Android 14/15/16 com câmera e GPS reais.

## Usar a versão Web local durante o desenvolvimento

A interface está em `app/src/main/assets/`:

```bash
cd app/src/main/assets
python -m http.server 8080
# acessar http://localhost:8080 em um navegador
```

A versão no Chrome permite testar a interface, cadastros, rascunho e assinatura. Para salvar PDF no Chrome, abra a impressão e escolha **Salvar como PDF** manualmente. O salvamento A4 automatizado com reinício da OS ocorre no APK Android. As funcionalidades de exportar/importar PDFs GOV.BR com cópia preservada e foto com seletor de câmera dependem do app Android.

## Configurar assinatura por link

**Sem hospedagem HTTPS, o botão de gerar link não funciona.** Leia `server/README.md` para instalar o servidor. Depois de publicado, abra Configurações no app e informe a URL HTTPS e `ADMIN_KEY`.

1. Preencha a OS com cliente e título; salve rascunho.
2. Abra Assinaturas → **Gerar link para assinatura** → **Compartilhar link**.
3. Cliente abre o link em seu celular, confere serviço, desenha assinatura e aceita.
4. No app técnico, **Consultar assinatura**; o desenho, data/hora e coordenadas autorizadas são importados.
5. **Gerar PDF e finalizar OS** para imprimir/salvar a OS e liberar a seguinte.

## Importante — segurança, privacidade e uso real

- Esta versão é um **protótipo funcional local**: cadastro de usuários = cadastro de perfis/equipe, **não sistema de login com senhas, papéis de acesso ou controle multiusuário**.
- Dados de clientes e OS ficam no armazenamento **local do WebView**, não sincronizados entre aparelhos; faça backup antes de limpar dados/desinstalar. A chave do servidor fica armazenada localmente e **não é criptografada por usuário**. Não use informações sensíveis em produção sem backend seguro, autenticação e criptografia.
- O link de assinatura constitui **assinatura eletrônica simples com registro técnico**, não certificado ICP-Brasil nem assinatura avançada GOV.BR. O servidor não comprova a identidade civil de quem usa o link, que pode ser encaminhado a terceiros.
- A geolocalização é opcional, só registrada com permissão; **nunca são inventadas coordenadas**. As horas da assinatura presencial vêm do relógio do aparelho; as remotas vêm do servidor.
- Não há verificação automática de um PDF GOV.BR. A importação armazena os bytes sem aplicar modificações posteriores que poderiam invalidar o certificado.
- Para implantação comercial são recomendados: API de usuários autenticados, banco persistente, isolamento por organização, política LGPD/retenção, backups seguros, logs de auditoria protegidos, criptografia, assinatura release, revisão de segurança e testes de integração em hardware real.

## Estrutura

```text
app/                  Projeto Android e gerador PDF nativo
app/src/main/assets/  HTML, CSS, JS responsivos
server/               API + página pública de assinatura por link
.github/workflows/    Workflow que compila APK automaticamente
tests/                Testes de interface (requer ambiente Chrome habilitado)
```

## Versão 1.1 — identificação nas assinaturas

Informe o nome completo antes da assinatura do cliente ou técnico; o nome aparecerá no PDF junto de data, horário e localização autorizada. Salvar bloqueia os campos e Limpar permite coletar novamente.
