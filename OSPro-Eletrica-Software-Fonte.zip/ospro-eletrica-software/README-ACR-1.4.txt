ACR Suporte em T.I - OS Pro 1.4
Identidade ACR no cabeçalho, painel e icone Android.
Marca ACR no PDF por padrão; é possível alterar em Configurações.
Dados anteriores são mantidos se a atualização do APK for compatível com a assinatura instalada.
