ACR SUPORTE EM T.I — OS PRO v1.5
LOGIN E CADASTRO LOCAIS DE USUARIOS
- Primeiro acesso: crie o administrador sem senha predefinida.
- Depois de entrar: Usuarios > Cadastrar usuario com nome, login, senha e perfil.
- Senhas protegidas por PBKDF2-SHA256 com salt individual e 210 mil iteracoes.
- Administrador tem acesso completo. Tecnico e Atendimento acessam Painel, OS, Assinaturas e Clientes.
- O login NAO criptografa dados locais e NAO sincroniza usuarios com o servidor de assinatura.
- Backups JSON incluem dados de OS, mas nao armazenam senhas nem hashes.
- Anote a senha do administrador: nao existe recuperacao remota nesta versao.
- Faca backup de suas OS antes de remover o aplicativo antigo.
