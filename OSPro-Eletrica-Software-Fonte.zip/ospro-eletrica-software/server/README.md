# Servidor de assinatura remota OS Pro

Servidor Node.js 20+ sem dependências NPM externas. **Requer hospedagem pública HTTPS** e disco persistente para o arquivo JSON de assinaturas.

## Configuração

Crie um serviço web Node (Render, Railway, VPS, Docker ou equivalente). Diretório de trabalho: `server`, comando inicial:

```bash
npm start
```

Variáveis de ambiente:

```ini
PORT=3000
PUBLIC_BASE_URL=https://assinaturas.seudominio.com.br
ADMIN_KEY=substitua-por-uma-chave-aleatoria-de-pelo-menos-32-caracteres
DATA_FILE=/dados-ospro/requests.json
```

**Não envie ADMIN_KEY para um repositório público.** Configure-a exclusivamente no painel de variáveis da hospedagem e no painel Configurações do app. Use `openssl rand -hex 32` para gerar uma chave randômica.

No app: Configurações → URL HTTPS e Chave privada. O cliente recebe só o endereço de seu link aleatório e nunca recebe a chave de administração.

As rotas estão no `server.js`:

- `POST /api/sign-requests` (cabeçalho `X-API-Key`): cria link, duração de sete dias.
- `GET /api/sign-requests/:id` (cabeçalho `X-API-Key`): consulta assinatura capturada.
- `GET /s/:token`: página de assinatura para o cliente.
- `GET /api/public/:token`: consulta pública reduzida sobre o pedido.
- `POST /api/public/:token/sign`: envia assinatura simples, com consentimento, apenas uma vez.
- `GET /health`: estado do serviço.

CORS permite a origem `https://appassets.androidplatform.net` usada pelo APK e origens locais de desenvolvimento. **Não use HTTP público**. Sem `PUBLIC_BASE_URL` HTTPS e `ADMIN_KEY` forte, o processo **não inicia**.

A persistência é em arquivo (`DATA_FILE`) com renomeação atômica; não é adequado para várias instâncias/alto tráfego. O servidor executa com **uma instância** e volume persistente. Se o provedor limpar discos a cada deploy, os links e assinaturas serão perdidos. Para produção, migre para banco transacional com criptografia e controle de acesso.

## Testar

```bash
cd server
npm test
```

## Limitações e auditoria

- Nome declarado pelo signatário, traço desenhado, IP transformado em hash, agente de usuário, carimbo de hora do servidor, hash de auditoria e localização **apenas se autorizada**.
- A página informa que a assinatura não equivale a GOV.BR ou certificado digital.
- O link expira e não aceita segunda assinatura; remova/purguе periodicamente registros vencidos conforme política LGPD.
- Link pode ser compartilhado pelo destinatário; para aumentar garantia de identidade é necessária autenticação real (OTP verificado, login com identidade ou prestador de assinatura).
- Proteja administrativamente a chave e não exponha logs/diretório de dados na web pública.
