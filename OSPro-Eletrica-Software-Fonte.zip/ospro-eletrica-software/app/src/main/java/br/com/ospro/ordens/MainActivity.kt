package br.com.ospro.ordens

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewAssetLoader.AssetsPathHandler
import org.json.JSONObject
import org.json.JSONArray
import java.io.File
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.util.Base64

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private var cameraResult: ValueCallback<Array<Uri>>? = null
    private var cameraUri: Uri? = null
    private var lastPdfUri: Uri? = null
    private var geoCallback: GeolocationPermissions.Callback? = null
    private var geoOrigin: String? = null
    private val pdfBusy = java.util.concurrent.atomic.AtomicBoolean(false)

    private val photoPicker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val result = if (r.resultCode == Activity.RESULT_OK) {
            if (r.data?.data != null || r.data?.clipData != null)
                WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data)
            else cameraUri?.let { arrayOf(it) }
        } else null
        cameraResult?.onReceiveValue(result)
        cameraResult = null
        cameraUri = null
    }
    private val locationPermission = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { response ->
        val granted = response[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            response[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        geoCallback?.invoke(geoOrigin, granted, false)
        geoCallback = null
        geoOrigin = null
    }
    private val govPdfPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) {
            jsCallback("onGovPdfImported", JSONObject().put("success", false).put("cancelled", true))
        } else {
            try {
                val filename = "OSPro-GOVBR-${System.currentTimeMillis()}.pdf"
                val dest = createDocument(filename, "application/pdf")
                contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "Não foi possível ler o PDF selecionado" }
                    contentResolver.openOutputStream(dest).use { output ->
                        requireNotNull(output) { "Falha ao abrir destino para salvar" }
                        input.copyTo(output)
                    }
                }
                lastPdfUri = dest
                getSharedPreferences("ospro", MODE_PRIVATE).edit().putString("lastPdf",dest.toString()).apply()
                jsCallback("onGovPdfImported", JSONObject().put("success", true).put("name", filename))
            } catch (e: Exception) {
                jsCallback("onGovPdfImported", JSONObject().put("success", false).put("error", e.message ?: "Erro ao importar PDF"))
            }
        }
    }

    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16,45,78)
        window.navigationBarColor = Color.rgb(16,45,78)
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", AssetsPathHandler(this))
            .build()
        webView = WebView(this)
        setContentView(webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = true
        webView.settings.mediaPlaybackRequiresUserGesture = true
        webView.settings.setGeolocationEnabled(true)
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest) = loader.shouldInterceptRequest(request.url)
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                if (uri.host == "appassets.androidplatform.net") return false
                if (uri.scheme == "https" || uri.scheme == "http") {
                    openExternal(uri.toString()); return true
                }
                return true
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(origin: String, callback: GeolocationPermissions.Callback) {
                if (origin != "https://appassets.androidplatform.net") {
                    callback.invoke(origin, false, false)
                    return
                }
                val granted = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                    ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                if (granted) callback.invoke(origin, true, false)
                else {
                    geoCallback = callback
                    geoOrigin = origin
                    locationPermission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                }
            }
            override fun onShowFileChooser(view: WebView, callback: ValueCallback<Array<Uri>>, params: WebChromeClient.FileChooserParams): Boolean {
                cameraResult?.onReceiveValue(null)
                cameraResult = callback
                return try {
                    val photoFile = File(File(cacheDir, "photos").apply { mkdirs() }, "camera-${System.currentTimeMillis()}.jpg")
                    val imageUri = FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", photoFile)
                    cameraUri = imageUri
                    val camera = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                        putExtra(MediaStore.EXTRA_OUTPUT, imageUri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                    }
                    val acceptsImage = params.acceptTypes.any { it.startsWith("image/") } || params.isCaptureEnabled
                    val canCamera = acceptsImage && camera.resolveActivity(packageManager) != null
                    val picker = try { params.createIntent() } catch (_: Exception) { Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE) } }
                    if (params.isCaptureEnabled && canCamera) {
                        photoPicker.launch(camera)
                    } else {
                        val chooser = Intent.createChooser(picker, "Selecionar foto / câmera")
                        if (canCamera) chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(camera))
                        photoPicker.launch(chooser)
                    }
                    true
                } catch (e: Exception) {
                    cameraResult?.onReceiveValue(null)
                    cameraResult = null
                    false
                }
            }
        }
        webView.addJavascriptInterface(AndroidBridge(), "Android")
        lastPdfUri = getSharedPreferences("ospro", MODE_PRIVATE).getString("lastPdf", null)?.let { Uri.parse(it) }
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    inner class AndroidBridge {
        @JavascriptInterface fun savePdf(data: String) {
            if (!pdfBusy.compareAndSet(false,true)) return
            Thread {
                val response = JSONObject()
                try {
                    val payload = JSONObject(data)
                    val os = payload.getJSONObject("order")
                    val filename = safeFileName(os.optString("numero", "OS")) + "-${System.currentTimeMillis()}.pdf"
                    val doc = ReportPdf(payload)
                    val uri = createDocument(filename, "application/pdf")
                    try {
                        contentResolver.openOutputStream(uri).use { output ->
                            requireNotNull(output) { "Não foi possível gravar o arquivo" }
                            doc.write(output)
                        }
                    } catch (e: Exception) { contentResolver.delete(uri, null, null); throw e }
                    lastPdfUri = uri
                    getSharedPreferences("ospro", MODE_PRIVATE).edit().putString("lastPdf", uri.toString()).apply()
                    response.put("success", true).put("name", filename).put("finalize", payload.optBoolean("finalize"))
                } catch (e: Exception) {
                    response.put("success", false).put("error", e.message ?: "Falha ao criar PDF")
                }
                finally {pdfBusy.set(false)}
                runOnUiThread {jsCallback("onPdfSaved", response)}
            }.start()
        }
        @JavascriptInterface fun saveBackup(data: String) { runOnUiThread {
            val result = JSONObject()
            try {
                val filename = "OSPro-backup-${System.currentTimeMillis()}.json"
                val uri = createDocument(filename, "application/json")
                try {
                    contentResolver.openOutputStream(uri).use { output ->
                        requireNotNull(output) { "Destino não disponível" }
                        output.write(data.toByteArray(Charsets.UTF_8))
                    }
                } catch (e: Exception) {contentResolver.delete(uri,null,null); throw e}
                result.put("success",true).put("name",filename)
            } catch (e: Exception) {result.put("success",false).put("error",e.message ?: "Falha ao salvar")}
            jsCallback("onBackupSaved",result)
        } }
        @JavascriptInterface fun sharePdf() { runOnUiThread {
            val uri = lastPdfUri
            if (uri == null) { android.widget.Toast.makeText(this@MainActivity, "Gere um PDF antes de compartilhar.", android.widget.Toast.LENGTH_LONG).show();return@runOnUiThread }
            val i = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"; putExtra(Intent.EXTRA_STREAM, uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(i, "Compartilhar ordem de serviço"))
        } }
        @JavascriptInterface fun shareText(value: String) { runOnUiThread {
            val intent = Intent(Intent.ACTION_SEND).apply {type = "text/plain";putExtra(Intent.EXTRA_TEXT, value.take(10000))}
            startActivity(Intent.createChooser(intent, "Compartilhar link com o cliente"))
        } }
        @JavascriptInterface fun openUrl(url: String) { runOnUiThread {openExternal(url)} }
        @JavascriptInterface fun importGovPdf() { runOnUiThread {govPdfPicker.launch(arrayOf("application/pdf"))} }
    }
    private fun openExternal(address: String) {
        try {
            val uri = Uri.parse(address)
            if (uri.scheme != "https") return
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (e: ActivityNotFoundException) {
            android.widget.Toast.makeText(this, "Navegador não disponível", android.widget.Toast.LENGTH_LONG).show()
        }
    }
    private fun jsCallback(method: String, data: JSONObject) {
        if (!::webView.isInitialized) return
        // JSONObject.quote safely escapes any error or document filename before use in JS.
        webView.evaluateJavascript("window.OSApp?.$method(${JSONObject.quote(data.toString())});", null)
    }
    private fun safeFileName(s: String) = s.replace(Regex("[^A-Za-z0-9_-]"), "_").take(60)
    private fun createDocument(filename: String, mime: String): Uri {
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, filename)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/OS-Pro")
            }
            return requireNotNull(contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)) { "Não foi possível salvar em Downloads" }
        }
        val directory = File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "OS-Pro")
        directory.mkdirs()
        val file = File(directory, filename)
        file.createNewFile()
        return FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
    }
    override fun onDestroy() { super.onDestroy(); webView.destroy() }
}

private class ReportPdf(private val input: JSONObject) {
    private val doc = PdfDocument()
    private val width = 595
    private val height = 842
    private val left = 42f
    private val right = 553f
    private var page: PdfDocument.Page? = null
    private var canvas: Canvas? = null
    private var y = 102f
    private var index = 0
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {color=Color.rgb(29,48,70); textSize=10.5f}
    private val navy = Color.rgb(16,45,78)
    private val gold = Color.rgb(227,168,46)
    private val money = NumberFormat.getCurrencyInstance(Locale("pt","BR"))
    private fun json(k:String) = input.optJSONObject(k) ?: JSONObject()
    private val os=json("order")
    private val client=json("client")
    private val tech=json("tech")
    private val company=json("company")
    private val photos=input.optJSONArray("photos") ?: JSONArray()
    private val logo: Bitmap? = try {
        val data=company.optString("logoData")
        if(!data.startsWith("data:image/png;base64,")) null else {
            val bytes=Base64.decode(data.substringAfter("base64,"),Base64.DEFAULT)
            if(bytes.size>800000) null else BitmapFactory.decodeByteArray(bytes,0,bytes.size)
        }
    } catch (_: Exception){null}

    private fun beginPage() {
        page?.let {doc.finishPage(it)}
        index++
        page=doc.startPage(PdfDocument.PageInfo.Builder(width,height,index).create())
        canvas=page!!.canvas
        val cv=canvas!!
        paint.color=Color.WHITE;cv.drawColor(Color.WHITE)
        paint.color=navy;cv.drawRect(0f,0f,width.toFloat(),75f,paint)
        paint.color=gold;cv.drawRect(0f,75f,width.toFloat(),79f,paint)
        var textX=left
        logo?.let { bitmap ->
            // A logo conserva seu formato original sobre fundo branco, inclusive no cabeçalho azul.
            paint.color=Color.WHITE
            cv.drawRoundRect(RectF(left,9f,left+111f,68f),5f,5f,paint)
            val ratio=minOf(103f/bitmap.width,51f/bitmap.height)
            val w=bitmap.width*ratio;val h=bitmap.height*ratio
            val x=left+(111f-w)/2f;val y0=9f+(59f-h)/2f
            cv.drawBitmap(bitmap,null,RectF(x,y0,x+w,y0+h),paint)
            textX=left+123f
        }
        paint.color=Color.WHITE;paint.typeface=Typeface.create(Typeface.DEFAULT,Typeface.BOLD);paint.textSize=if(logo==null)18f else 14f
        val empresa=company.optString("empresa","OS PRO").ifBlank {"OS PRO"}
        cv.drawText(empresa.take(if(logo==null)46 else 31),textX,33f,paint)
        paint.typeface=Typeface.DEFAULT;paint.textSize=if(logo==null)11f else 10f
        cv.drawText("ORDEM DE SERVIÇO  •  ${os.optString("numero").take(28)}",textX,55f,paint)
        paint.color=Color.LTGRAY;cv.drawLine(left,809f,right,809f,paint)
        paint.color=navy;paint.textSize=8.5f
        cv.drawText("OS Pro Elétrica & Software   |   ${timestamp(Date())}",left,825f,paint)
        cv.drawText("Página $index",right-50f,825f,paint)
        paint.color=Color.rgb(29,48,70);paint.textSize=10.5f
        y=104f
    }
    private fun room(required: Float){if(y+required>795f)beginPage()}
    private fun section(name:String){room(47f);y+=11f;paint.color=Color.rgb(231,241,250);canvas!!.drawRoundRect(RectF(left,y-14f,right,y+17f),5f,5f,paint);paint.color=navy;paint.textSize=12f;paint.typeface=Typeface.create(Typeface.DEFAULT,Typeface.BOLD);canvas!!.drawText(name,left+10f,y+6f,paint);paint.typeface=Typeface.DEFAULT;paint.textSize=10.5f;y+=29f}
    private fun chunks(text: String, maxWidth:Float):List<String> {
        val lines=mutableListOf<String>()
        for (raw in text.replace("\r","").split('\n')) {
            if(raw.isEmpty()){lines.add("");continue}
            var current=""
            for(word in raw.split(Regex("\\s+"))){
                if(word.isBlank())continue
                var segment=word
                while(paint.measureText(segment)>maxWidth){
                    if(current.isNotBlank()){lines.add(current);current=""}
                    var size=1
                    while(size<segment.length && paint.measureText(segment.substring(0,size+1))<maxWidth)size++
                    lines.add(segment.substring(0,size));segment=segment.substring(size)
                }
                val proposed=if(current.isEmpty())segment else "$current $segment"
                if(paint.measureText(proposed)>maxWidth && current.isNotEmpty()){lines.add(current);current=segment}else current=proposed
            }
            lines.add(current)
        }
        return lines
    }
    private fun line(text:String, bold:Boolean=false) {
        paint.typeface=if(bold) Typeface.create(Typeface.DEFAULT,Typeface.BOLD) else Typeface.DEFAULT
        paint.textSize=10.5f
        for(t in chunks(text,right-left-5f)){
            room(15f);canvas!!.drawText(t,left,y,paint);y+=14.5f
        }
        paint.typeface=Typeface.DEFAULT
    }
    private fun field(label:String,value: String){line("$label: ${value.ifBlank {"Não informado"}}")}
    private fun paragraph(label:String,value:String){line(label,true);line(value.ifBlank {"Não informado"});y+=5f}
    private fun asMoney(k:String)=money.format(os.optDouble(k,0.0))
    private fun timestamp(date:Date):String=SimpleDateFormat("dd/MM/yyyy HH:mm:ss",Locale("pt","BR")).format(date)
    private fun formatIso(text:String):String=try {timestamp(Date.from(java.time.Instant.parse(text)))}catch (_: Exception){text.replace('T',' ')}
    private fun img(data: String,maxW:Float,maxH:Float) {
        val b64=data.substringAfter("base64,","")
        if(b64.isBlank())return
        try {
            val bytes=Base64.decode(b64,Base64.DEFAULT)
            val options=BitmapFactory.Options().apply{inJustDecodeBounds=true}
            BitmapFactory.decodeByteArray(bytes,0,bytes.size,options)
            options.inSampleSize=when {options.outWidth>3200->4;options.outWidth>1600->2;else->1}
            options.inJustDecodeBounds=false
            val bitmap=BitmapFactory.decodeByteArray(bytes,0,bytes.size,options) ?: return
            val ratio=minOf(maxW/bitmap.width,maxH/bitmap.height)
            val w=bitmap.width*ratio;val h=bitmap.height*ratio
            room(h+20f)
            paint.color=Color.rgb(246,248,251);canvas!!.drawRect(left,y-4f,left+w+5f,y+h+5f,paint)
            paint.color=Color.WHITE;canvas!!.drawBitmap(bitmap,null,RectF(left,y,left+w,y+h),paint)
            y+=h+15f
            bitmap.recycle();paint.color=Color.rgb(29,48,70)
        } catch (_: Exception) {line("Imagem indisponível.")}
    }
    private fun signature(label:String,obj:JSONObject?) {
        room(167f) // nome e imagem não devem se separar entre páginas
        line(label,true)
        if(obj==null){line("Assinatura não coletada.");y+=5f;return}
        field("Nome do assinante",obj.optString("name"))
        img(obj.optString("image"),245f,83f)
        field("Data e hora",formatIso(obj.optString("at")))
        val location=obj.optJSONObject("location")
        val loc=if(location==null)"Indisponível / não autorizada" else {
            "${location.optDouble("lat")}, ${location.optDouble("lon")} (precisão aproximada ${location.optDouble("accuracy").toInt()} m)"
        }
        field("Geolocalização",loc)
        field("Coleta",if(obj.optString("source")=="remote")"Link remoto" else "Presencial na tela")
        val audit=obj.optString("audit")
        if(audit.isNotBlank())field("Protocolo de auditoria",audit)
        y+=8f
    }
    fun write(out:java.io.OutputStream) {
        try {
            beginPage()
            section("Dados da ordem")
            field("Número",os.optString("numero"))
            field("Abertura",os.optString("abertura").replace('T',' '))
            field("Tipo",os.optString("tipo"))
            field("Status",os.optString("status"))
            field("Prioridade",os.optString("prioridade"))
            field("Previsão",os.optString("previsao"))
            section("Cliente e responsável")
            field("Cliente",client.optString("nome"))
            field("CPF/CNPJ",client.optString("documento"))
            field("Telefone",client.optString("telefone"))
            field("E-mail",client.optString("email"))
            field("Endereço",client.optString("endereco"))
            field("Técnico",tech.optString("nome"))
            section("Atendimento")
            paragraph("Título",os.optString("titulo"))
            paragraph("Solicitação / defeito",os.optString("descricao"))
            paragraph("Diagnóstico",os.optString("diagnostico"))
            paragraph("Serviço executado",os.optString("execucao"))
            paragraph("Materiais / observações",os.optString("materiais"))
            section("Valores")
            field("Mão de obra",asMoney("maoObra"))
            field("Materiais",asMoney("custoMateriais"))
            field("Deslocamento",asMoney("deslocamento"))
            field("Desconto",asMoney("desconto"))
            val total=maxOf(0.0,os.optDouble("maoObra",0.0)+os.optDouble("custoMateriais",0.0)+os.optDouble("deslocamento",0.0)-os.optDouble("desconto",0.0))
            line("VALOR TOTAL: ${money.format(total)}",true)
            section("Assinaturas")
            val signatures=os.optJSONObject("signatures") ?: JSONObject()
            signature("Cliente",signatures.optJSONObject("cliente"))
            signature("Técnico",signatures.optJSONObject("tecnico"))
            section("Evidências fotográficas")
            if(photos.length()==0)line("Nenhuma imagem anexada.")
            for(i in 0 until photos.length()){
                val picture=photos.optJSONObject(i) ?: continue
                line("Foto ${i+1}: ${picture.optString("name")}",true)
                img(picture.optString("image"),470f,300f)
            }
            line("Registro local: a assinatura manuscrita em tela e a assinatura por link não são certificados digitais GOV.BR.")
            page?.let {doc.finishPage(it)}
            page=null
            doc.writeTo(out)
        } finally {doc.close();logo?.recycle()}
    }
}
