/* OS Pro - HTML/JS offline UI; Android handles native A4 PDF and document import. */
(() => {
  'use strict';
  const VERSION = 1;
  const KEY = 'ospro:database:v1';
  const $ = s => document.querySelector(s);
  const $$ = s => [...document.querySelectorAll(s)];
  const clone = obj => JSON.parse(JSON.stringify(obj));
  const now = () => new Date().toISOString();
  const money = n => new Intl.NumberFormat('pt-BR', {style:'currency', currency:'BRL'}).format(+n||0);
  const uid = () => (crypto.randomUUID ? crypto.randomUUID() : 'id'+Date.now()+Math.random().toString(36).slice(2));
  const pad = n => String(n).padStart(2,'0');
  const dateInput = () => { const d=new Date(); return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`; };
  const dateTimeInput = () => { const d=new Date();return `${dateInput()}T${pad(d.getHours())}:${pad(d.getMinutes())}`; };
  const showDate = iso => {if(!iso)return '—'; const d = new Date(iso); return isNaN(+d) ? String(iso) : d.toLocaleString('pt-BR');};
  const emptyOrder = (seq = 1) => ({id:uid(),numero:`OS-${new Date().getFullYear()}-${String(seq).padStart(5,'0')}`,abertura:dateTimeInput(), clienteId:'',tecnicoId:'',tipo:'Elétrica',status:'Aberta',prioridade:'Normal',previsao:'',titulo:'',descricao:'',diagnostico:'',execucao:'',materiais:'',maoObra:0,custoMateriais:0,deslocamento:0,desconto:0,photos:[],signatures:{cliente:null,tecnico:null},remote:null,updatedAt:now()});
  const initial = () => ({version:VERSION,seq:2,current:emptyOrder(1),orders:[],clients:[],users:[],finance:[],settings:{empresa:'',empresaDoc:'',empresaContato:'',serverUrl:'',apiKey:''},preferences:{contrast:false,large:false}});
  let db;
  try { db = JSON.parse(localStorage.getItem(KEY)) || initial(); if(!db.current || !Array.isArray(db.orders))throw new Error('Bad local state'); } catch { db = initial(); }
  db.clients ||= []; db.users ||= []; db.finance ||= []; db.settings ||= initial().settings; db.preferences ||= {};
  db.current.signatures ||= {cliente:null,tecnico:null}; db.current.photos ||= [];
  const save = () => { try{localStorage.setItem(KEY,JSON.stringify(db));}catch(e){alert('Não foi possível salvar. O armazenamento do aparelho pode estar cheio. Faça backup.'); throw e;} };
  const escape = s => String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const findClient = id => db.clients.find(x=>x.id===id);
  const findTech = id => db.users.find(x=>x.id===id);
  const orderTotal = o => Math.max(0,(+o.maoObra||0)+(+o.custoMateriais||0)+(+o.deslocamento||0)-(+o.desconto||0));
  let activeTab='painel', activeRole='cliente', drawn=false, pendingPdf=false;
  const pendingSignNames={cliente:'',tecnico:''};
  let toastTimer;
  function toast(message, error=false){const el=$('#toast');el.textContent=message;el.className='toast show'+(error?' error':'');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.className='toast',4700);}
  function tab(name){activeTab=name; $$('.pane').forEach(x=>x.classList.toggle('active',x.id===name));$$('.top-nav button').forEach(x=>{const yes=x.dataset.tab===name;x.classList.toggle('active',yes);x.setAttribute('aria-current',yes?'page':'false')});window.scrollTo(0,0); if(name==='assinaturas')renderSignature();}
  $$('[data-tab]').forEach(b=>b.addEventListener('click',()=>tab(b.dataset.tab)));
  $('#quick-os').onclick=()=>{newOrderPrompt();tab('ordens');};$('#go-os').onclick=()=>tab('ordens');$('#go-sign').onclick=()=>tab('assinaturas');$('#to-sign').onclick=()=>{saveOrderForm(false);tab('assinaturas');};
  function formData(form){const result={};new FormData(form).forEach((v,k)=>result[k]=String(v));return result;}
  function setForm(form,obj){for(const input of form.elements){if(!input.name || input.type==='file')continue; if(Object.prototype.hasOwnProperty.call(obj,input.name))input.value=String(obj[input.name]??'');}}
  function optionHtml(items,placeholder){return `<option value="">${escape(placeholder)}</option>`+items.map(x=>`<option value="${escape(x.id)}">${escape(x.nome)}</option>`).join('');}
  function updateSelections(){const c=$('#os-client'),u=$('#os-tech');const oldC=c.value||db.current.clienteId,oldU=u.value||db.current.tecnicoId;c.innerHTML=optionHtml(db.clients,'Selecione o cliente');u.innerHTML=optionHtml(db.users,'Selecione o responsável');c.value=oldC;u.value=oldU;}
  function syncOrderForm(){updateSelections();setForm($('#os-form'),db.current);$('#os-number').value=db.current.numero;$('#finance-os').placeholder=db.current.numero;updateTotal();renderPhotos();renderRemote();}
  function updateTotal(){const o=formData($('#os-form'));$('#os-total').textContent=money(orderTotal(o));}
  $$('input[name="maoObra"],input[name="custoMateriais"],input[name="deslocamento"],input[name="desconto"]').forEach(x=>x.addEventListener('input',updateTotal));
  function saveOrderForm(announce=true){const data=formData($('#os-form'));Object.assign(db.current,data,{updatedAt:now()});db.current.maoObra=Math.max(0,+data.maoObra||0);db.current.custoMateriais=Math.max(0,+data.custoMateriais||0);db.current.deslocamento=Math.max(0,+data.deslocamento||0);db.current.desconto=Math.max(0,+data.desconto||0);save();renderDashboard();if(announce)toast('Rascunho da ordem salvo neste aparelho.');return db.current;}
  $('#os-form').onsubmit=e=>{e.preventDefault();if(!$('#os-form').reportValidity())return;saveOrderForm();};
  function newOrderPrompt(){const old=db.current; if(old.titulo||old.descricao||old.signatures.cliente||old.signatures.tecnico){if(!confirm('Iniciar nova OS? O rascunho atual ainda não foi finalizado e será substituído.'))return false;}createNew();return true;}
  function createNew(){pendingSignNames.cliente='';pendingSignNames.tecnico='';db.current=emptyOrder(db.seq++);save();syncOrderForm();renderSignature();renderDashboard();toast('Novo formulário de ordem de serviço pronto.');}
  $('#new-os').onclick=newOrderPrompt;
  function finalizeOrder(kind){saveOrderForm(false);const completed=clone(db.current);completed.closedAt=now();completed.finalizacao=kind;db.orders.unshift(completed);db.current=emptyOrder(db.seq++);pendingSignNames.cliente='';pendingSignNames.tecnico='';save();syncOrderForm();renderAll();tab('ordens');toast('PDF salvo. Ordem arquivada e novo atendimento liberado.');}
  function renderDashboard(){const sum=t=>db.finance.filter(x=>x.tipo===t).reduce((a,x)=>a+(+x.valor||0),0);$('#stat-os').textContent=String(db.orders.length);$('#stat-income').textContent=money(sum('receita'));$('#stat-expense').textContent=money(sum('despesa'));$('#stat-balance').textContent=money(sum('receita')-sum('despesa'));const o=db.current;$('#draft-indicator').textContent=o.numero;$('#current-summary').innerHTML=o.titulo?`<strong>${escape(o.numero)} — ${escape(o.titulo)}</strong><br>${escape(o.tipo)} • ${escape(findClient(o.clienteId)?.nome||'Cliente não selecionado')} • ${money(orderTotal(o))}`:`${escape(o.numero)}: preencha os dados e salve o rascunho.`;const row=x=>`<div class="item"><div><strong>${escape(x.numero)} · ${escape(x.titulo||'Sem título')}</strong><small>${escape(findClient(x.clienteId)?.nome||'Cliente não encontrado')} · ${escape(x.finalizacao)} · ${showDate(x.closedAt)}</small></div><div class="item-side"><b>${money(orderTotal(x))}</b></div></div>`;$('#recent-list').innerHTML=db.orders.slice(0,5).map(row).join('')||'<div class="empty">Nenhuma ordem finalizada ainda.</div>';$('#os-history').innerHTML=db.orders.map(row).join('')||'<div class="empty">Seu histórico de ordens aparecerá aqui.</div>';}
  function attachForm(formId,fieldName,collection,render){const form=$(formId);form.addEventListener('submit',e=>{e.preventDefault();if(!form.reportValidity())return;const f=formData(form),id=f.id||uid();let existing=db[collection].find(x=>x.id===id);if(existing)Object.assign(existing,f,{id});else db[collection].push({...f,id});save();form.reset();form.elements.namedItem('id').value='';render();updateSelections();toast(`${fieldName} salvo(a).`);});}
  attachForm('#client-form','Cliente','clients',renderClients);attachForm('#user-form','Usuário','users',renderUsers);
  function rowEntity(x,type){return `<div class="item"><div><strong>${escape(x.nome)}</strong><small>${escape(x.email||x.telefone||x.documento||x.perfil||'Sem contato')}</small></div><div class="item-side"><button type="button" data-edit="${escape(type)}" data-id="${escape(x.id)}">Editar</button><button type="button" class="danger" data-delete="${escape(type)}" data-id="${escape(x.id)}">Excluir</button></div></div>`;}
  function renderClients(){$('#client-list').innerHTML=db.clients.map(x=>rowEntity(x,'clients')).join('')||'<div class="empty">Nenhum cliente cadastrado.</div>';}
  function renderUsers(){$('#user-list').innerHTML=db.users.map(x=>rowEntity(x,'users')).join('')||'<div class="empty">Nenhum usuário cadastrado.</div>';}
  document.addEventListener('click',e=>{const edit=e.target.closest('[data-edit]'),del=e.target.closest('[data-delete]');if(edit){const type=edit.dataset.edit,record=db[type].find(x=>x.id===edit.dataset.id);if(!record)return;const form=type==='clients'?$('#client-form'):$('#user-form');setForm(form,record);tab(type==='clients'?'clientes':'usuarios');form.scrollIntoView({behavior:'smooth'});}if(del){const type=del.dataset.delete,id=del.dataset.id;if(type==='clients' && (db.orders.some(x=>x.clienteId===id)||db.current.clienteId===id)){toast('Cliente vinculado a OS: exclusão bloqueada.',true);return;}if(type==='users' && (db.orders.some(x=>x.tecnicoId===id)||db.current.tecnicoId===id)){toast('Usuário vinculado a OS: exclusão bloqueada.',true);return;}if(!confirm('Confirma a exclusão deste cadastro?'))return;db[type]=db[type].filter(x=>x.id!==id);save();renderAll();}});
  $('#finance-form').onsubmit=e=>{e.preventDefault();const f=formData(e.currentTarget);if(!e.currentTarget.reportValidity())return;db.finance.unshift({...f,id:uid(),valor:+f.valor});save();e.currentTarget.reset();e.currentTarget.elements.namedItem('data').value=dateInput();renderFinance();renderDashboard();toast('Lançamento financeiro registrado.');};
  function renderFinance(){$('#finance-list').innerHTML=db.finance.map(x=>`<div class="item"><div><strong>${escape(x.descricao)}</strong><small>${escape(x.data)} · ${escape(x.forma)} · ${escape(x.osNumero||'Sem OS')}</small></div><div class="item-side"><b class="${x.tipo==='receita'?'money-plus':'money-minus'}">${x.tipo==='receita'?'+':'−'} ${money(x.valor)}</b><button data-del-fin="${escape(x.id)}" type="button">Excluir</button></div></div>`).join('')||'<div class="empty">Nenhuma movimentação registrada.</div>';}
  document.addEventListener('click',e=>{const b=e.target.closest('[data-del-fin]');if(!b||!confirm('Excluir este lançamento?'))return;db.finance=db.finance.filter(x=>x.id!==b.dataset.delFin);save();renderFinance();renderDashboard();});
  // IndexedDB separates photos from the smaller localStorage dataset.
  function photoDb(){return new Promise((resolve,reject)=>{const req=indexedDB.open('ospro-photos',1);req.onupgradeneeded=()=>{if(!req.result.objectStoreNames.contains('photos'))req.result.createObjectStore('photos');};req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});}
  async function photoOp(mode,key,val){const database=await photoDb();return new Promise((resolve,reject)=>{const tr=database.transaction('photos',mode==='get'?'readonly':'readwrite');const obj=tr.objectStore('photos');const r=mode==='get'?obj.get(key):mode==='delete'?obj.delete(key):obj.put(val,key);r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);tr.oncomplete=()=>database.close();});}
  const toBase64=(blob)=>new Promise((resolve,reject)=>{const fr=new FileReader();fr.onload=()=>resolve(fr.result);fr.onerror=()=>reject(fr.error);fr.readAsDataURL(blob);});
  async function resizePhoto(file){const source=await toBase64(file);return new Promise((resolve,reject)=>{const img=new Image();img.onload=()=>{const max=1100,scale=Math.min(1,max/Math.max(img.width,img.height)),c=document.createElement('canvas');c.width=Math.round(img.width*scale);c.height=Math.round(img.height*scale);c.getContext('2d').drawImage(img,0,0,c.width,c.height);resolve(c.toDataURL('image/jpeg',.75));};img.onerror=()=>reject(new Error('Imagem inválida'));img.src=source;});}
  $('#photo-input').onchange=async e=>{const file=e.target.files?.[0];if(!file)return;try{if(!file.type.startsWith('image/'))throw Error('Selecione uma imagem.');const base=await resizePhoto(file),id=uid();await photoOp('put',id,base);db.current.photos.push({id,name:file.name||'Foto do serviço'});save();renderPhotos();toast('Foto adicionada às evidências.');}catch(err){toast(err.message||'Falha na imagem.',true);}e.target.value='';};
  async function renderPhotos(){const container=$('#photo-list');const items=clone(db.current.photos);container.innerHTML='';for(const item of items){try{const uri=await photoOp('get',item.id);if(!uri)continue;const card=document.createElement('div');card.className='photo-card';const pic=document.createElement('img');pic.src=uri;pic.alt=item.name;const btn=document.createElement('button');btn.textContent='Remover';btn.onclick=async()=>{await photoOp('delete',item.id);db.current.photos=db.current.photos.filter(x=>x.id!==item.id);save();renderPhotos();};card.append(pic,btn);container.append(card);}catch(err){console.warn('Foto não disponível',err);}}}
  async function getOrderPhotos(){const list=[];for(const x of db.current.photos){try{const uri=await photoOp('get',x.id);if(uri)list.push({name:x.name,image:uri});}catch{}}return list;}
  // Signature canvas: use Pointer Events and device-pixel scaling to prevent touch offset.
  const canvas=$('#signature-canvas'),ctx=canvas.getContext('2d',{willReadFrequently:false});
  function fitCanvas(){const r=canvas.getBoundingClientRect();if(r.width<2)return;const dpr=Math.min(devicePixelRatio||1,3);canvas.width=Math.round(r.width*dpr);canvas.height=Math.round(r.height*dpr);ctx.setTransform(dpr,0,0,dpr,0,0);ctx.strokeStyle='#172c48';ctx.lineWidth=2.5;ctx.lineCap='round';ctx.lineJoin='round';}
  let signatureRenderId=0;
  function displaySignature(image){const version=++signatureRenderId;if(!canvas.getBoundingClientRect().width)return;fitCanvas();if(image){const img=new Image();img.onload=()=>{if(version!==signatureRenderId)return;const r=canvas.getBoundingClientRect();ctx.drawImage(img,0,0,r.width,r.height);};img.src=image;}}
  const currentSign=()=>db.current.signatures[activeRole];
  const signName=$('#sign-name');
  const signSuggestedName=()=>activeRole==='cliente'?(findClient(db.current.clienteId)?.nome||''):(findTech(db.current.tecnicoId)?.nome||'');
  function updateSignButtons(){const a=!!currentSign();$('#save-sign').disabled=a||!drawn||!signName.value.trim();$('#clear-sign').disabled=!a&&!drawn;}
  function renderSignature(){
    const a=currentSign();drawn=false;
    $$('[data-sign-role]').forEach(b=>b.classList.toggle('active',b.dataset.signRole===activeRole));
    $('#sign-person').textContent=activeRole==='cliente'?'Assinatura do cliente':'Assinatura do técnico';
    signName.value=a?.name||pendingSignNames[activeRole]||signSuggestedName();signName.readOnly=!!a;
    displaySignature(a?.image||null);updateSignButtons();
    $('#sign-status').textContent=a?'Assinatura salva. Salvar bloqueado; use Limpar para substituir.':signName.value.trim()?'Nome informado. Agora assine com o dedo ou caneta.':'Informe o nome completo antes de assinar.';
    $('#sign-metadata').textContent=a?`Assinante: ${a.name||'Não informado'} | ${showDate(a.at)} | Localização: ${a.location?.lat!=null?`${a.location.lat.toFixed(6)}, ${a.location.lon.toFixed(6)} (precisão aprox. ${Math.round(a.location.accuracy||0)}m)`:'indisponível / não autorizada'} | Origem: ${a.source==='remote'?'link remoto':'presencial'}`:'';
  }
  signName.addEventListener('input',()=>{pendingSignNames[activeRole]=signName.value;updateSignButtons();});
  $$('[data-sign-role]').forEach(b=>b.onclick=()=>{activeRole=b.dataset.signRole;renderSignature();});
  let writing=false,last=null;
  const point=e=>{const rect=canvas.getBoundingClientRect();return{x:e.clientX-rect.left,y:e.clientY-rect.top};};
  canvas.addEventListener('pointerdown',e=>{if(currentSign())return;if(!signName.value.trim()){toast('Informe o nome completo antes de assinar.',true);signName.focus();return;}e.preventDefault();canvas.setPointerCapture(e.pointerId);writing=true;last=point(e);ctx.beginPath();ctx.moveTo(last.x,last.y);ctx.lineTo(last.x+.15,last.y+.15);ctx.stroke();drawn=true;updateSignButtons();$('#sign-status').textContent='Assinatura desenhada. Toque em Salvar assinatura.';});
  canvas.addEventListener('pointermove',e=>{if(!writing||currentSign())return;e.preventDefault();const p=point(e);ctx.beginPath();ctx.moveTo(last.x,last.y);ctx.lineTo(p.x,p.y);ctx.stroke();last=p;});
  ['pointerup','pointercancel','lostpointercapture'].forEach(type=>canvas.addEventListener(type,()=>{writing=false;last=null;}));
  async function geolocate(){if(!navigator.geolocation)return null;return new Promise(resolve=>navigator.geolocation.getCurrentPosition(pos=>resolve({lat:pos.coords.latitude,lon:pos.coords.longitude,accuracy:pos.coords.accuracy}),()=>resolve(null),{enableHighAccuracy:true,timeout:10000,maximumAge:0}));}
  $('#save-sign').onclick=async()=>{
    if(!drawn||currentSign())return;
    const name=signName.value.trim().replace(/\s+/g,' ');
    if(!name){toast('Informe o nome completo antes de salvar.',true);signName.focus();return;}
    const role=activeRole,b=$('#save-sign');b.disabled=true;
    $('#sign-status').textContent='Registrando nome, data, horário e localização...';
    const position=await geolocate();if(db.current.signatures[role])return;
    pendingSignNames[role]=name;
    db.current.signatures[role]={name,image:canvas.toDataURL('image/png'),at:now(),location:position,source:'presencial'};
    saveOrderForm(false);renderSignature();toast('Assinatura e nome salvos.');
  };
  $('#clear-sign').onclick=()=>{
    if(!currentSign()&&!drawn)return;
    if(currentSign()&&!confirm('Remover a assinatura salva para colher outra?'))return;
    db.current.signatures[activeRole]=null;pendingSignNames[activeRole]=signName.value;
    save();drawn=false;renderSignature();toast('Assinatura limpa. Confira o nome e assine novamente.');
  };
  window.addEventListener('resize',()=>{if(activeTab==='assinaturas')renderSignature();});
  // Remote link requires an independent, published HTTPS Node service.
  function remoteConfig(){const raw=(db.settings.serverUrl||'').trim().replace(/\/+$/,'');if(!/^https:\/\/[^\s]+/i.test(raw))throw Error('Configure a URL HTTPS do servidor em Configurações.');if(!db.settings.apiKey)throw Error('Configure a chave privada ADMIN_KEY do servidor.');return {base:raw,key:db.settings.apiKey};}
  async function remoteFetch(path,method='GET',body){const {base,key}=remoteConfig();const ctrl=new AbortController();const timeout=setTimeout(()=>ctrl.abort(),15000);try{const res=await fetch(base+path,{method,headers:{'Content-Type':'application/json','X-API-Key':key},body:body?JSON.stringify(body):undefined,signal:ctrl.signal});const data=await res.json();if(!res.ok)throw Error(data.error||`Servidor: ${res.status}`);return data;}finally{clearTimeout(timeout);}}
  function renderRemote(){const remote=db.current.remote;$('#remote-url').value=remote?.url||'';$('#share-link').disabled=!remote?.url;$('#remote-status').textContent=remote?.signed?'Cliente assinou remotamente. Assinatura anexada à OS.':remote?.url?`Link ativo, aguardando cliente. Enviado em ${showDate(remote.createdAt)}.`:'Nenhum link gerado para esta OS.';}
  $('#create-link').onclick=async()=>{saveOrderForm(false);const o=db.current,client=findClient(o.clienteId);if(!client||!o.titulo){toast('Preencha título e cadastre/selecione um cliente na OS.',true);tab('ordens');return;}const b=$('#create-link');b.disabled=true;try{const response=await remoteFetch('/api/sign-requests','POST',{orderNumber:o.numero,clientName:client.nome,serviceTitle:o.titulo,summary:o.execucao||o.descricao,total:orderTotal(o)});o.remote={id:response.id,url:response.url,createdAt:now(),signed:false};save();renderRemote();toast('Link gerado. Agora compartilhe com o cliente.');}catch(e){toast(`Não foi possível gerar link: ${e.message}`,true);}finally{b.disabled=false;}};
  $('#share-link').onclick=()=>{const url=db.current.remote?.url;if(!url)return;const message=`Olá! Por favor, assine a ordem de serviço ${db.current.numero}: ${url}`;if(window.Android?.shareText)window.Android.shareText(message);else if(navigator.share)navigator.share({title:'Assinatura de ordem de serviço',text:message,url}).catch(()=>{});else navigator.clipboard?.writeText(message).then(()=>toast('Link copiado para a área de transferência.')).catch(()=>toast('Copie o link exibido acima.'));};
  $('#check-link').onclick=async()=>{const r=db.current.remote;if(!r?.id){toast('Gere um link antes de consultar.',true);return;}try{const res=await remoteFetch(`/api/sign-requests/${encodeURIComponent(r.id)}`);if(res.status==='signed'&&res.signature){db.current.signatures.cliente={image:res.signature.image,name:res.signature.name,at:res.signature.signedAt,location:res.signature.location||null,source:'remote',audit:res.signature.audit||''};db.current.remote.signed=true;save();renderSignature();renderRemote();toast('Assinatura do cliente recebida pelo link.');}else toast(`Situação atual: ${res.status==='pending'?'aguardando assinatura':res.status}.`);}catch(e){toast(`Falha ao consultar: ${e.message}`,true);}};
  async function pdfPayload(finalize){saveOrderForm(false);const o=db.current;const client=findClient(o.clienteId);if(!o.titulo||!client){tab('ordens');throw Error('Cadastre/selecione o cliente e informe o título da OS antes de gerar PDF.');}return JSON.stringify({finalize,order:clone(o),client:clone(client),tech:clone(findTech(o.tecnicoId)||{nome:'Não informado'}),company:clone(db.settings),photos:await getOrderPhotos()});}
  const safe=(str)=>String(str||'').replace(/[<>]/g,'');
  const printEscape = text => escape(String(text??'')).replace(/\n/g,'<br>');
  function webPrint(payload){const {order:o,client,tech,company,photos}=payload;const win=window.open('','_blank');if(!win)throw Error('Permita janelas pop-up ou utilize o APK Android.');const signature=role=>{const s=o.signatures[role];return `<h3>Assinatura ${role}</h3>${s?`<p><b>Assinante:</b> ${escape(s.name||'Nome não registrado')}</p><img style="width:250px;height:90px;object-fit:contain" src="${s.image}"><p>${printEscape(showDate(s.at))} | ${s.location?`${s.location.lat}, ${s.location.lon}`:'localização indisponível'}</p>`:'Não assinada'}`;};const html=`<!doctype html><html lang="pt-BR"><meta charset="utf-8"><title>${escape(o.numero)}</title><style>body{font:15px system-ui,sans-serif;margin:25px;color:#1b344e}h1{background:#102d4e;color:white;padding:18px}h2{border-bottom:2px solid #e3a82e;padding-bottom:6px}p{white-space:normal}img{max-width:100%}@page{size:A4;margin:18mm}</style><h1>${escape(company.empresa||'OS PRO')} — ${escape(o.numero)}</h1><h2>Identificação</h2><p>Cliente: ${escape(client.nome)}<br>Técnico: ${escape(tech.nome)}<br>Área: ${escape(o.tipo)}<br>Status: ${escape(o.status)}<br>Abertura: ${escape(o.abertura)}</p><h2>Serviço</h2><p><b>${escape(o.titulo)}</b></p><p>Solicitação: ${printEscape(o.descricao)}</p><p>Diagnóstico: ${printEscape(o.diagnostico)}</p><p>Execução: ${printEscape(o.execucao)}</p><p>Materiais: ${printEscape(o.materiais)}</p><h2>Valores</h2><p>Mão de obra: ${money(o.maoObra)} | Materiais: ${money(o.custoMateriais)} | Deslocamento: ${money(o.deslocamento)} | Desconto: ${money(o.desconto)}<br><b>Total: ${money(orderTotal(o))}</b></p><h2>Assinaturas</h2>${signature('cliente')}${signature('tecnico')}<h2>Fotos</h2>${photos.map(p=>`<div><p>${escape(p.name)}</p><img style="max-height:380px" src="${p.image}"></div>`).join('')}<p>Gerado em ${showDate(now())}</p></html>`;win.document.write(html);win.document.close();setTimeout(()=>win.print(),550);}
  async function generatePdf(finalize){if(pendingPdf)return;pendingPdf=true;const b=$('#finish-pdf');b.disabled=true;$('#pdf-status').textContent='Preparando documento com assinaturas e evidências...';try{const data=await pdfPayload(finalize);if(window.Android?.savePdf){window.Android.savePdf(data);return;}webPrint(JSON.parse(data));$('#pdf-status').textContent='Na janela de impressão do Chrome, selecione “Salvar como PDF”. A finalização automática ocorre apenas no APK Android.';toast('Visualização de impressão aberta.');}catch(e){$('#pdf-status').textContent=e.message;toast(e.message,true);}finally{if(!window.Android?.savePdf){pendingPdf=false;b.disabled=false;}}}
  $('#finish-pdf').onclick=()=>generatePdf(true);
  $('#share-pdf').onclick=()=>{if(window.Android?.sharePdf)window.Android.sharePdf();else toast('No Chrome, compartilhe o PDF depois de salvá-lo na impressão.');};
  $('#gov-export').onclick=()=>generatePdf(false);
  $('#gov-open').onclick=()=>{const url='https://assinador.iti.br/';if(window.Android?.openUrl)window.Android.openUrl(url);else window.open(url,'_blank','noopener');};
  $('#gov-import').onclick=()=>{if(!db.current.titulo||!findClient(db.current.clienteId)){toast('Preencha a OS antes de importar o documento assinado.',true);return;}if(!confirm('Confirme que você assinou no GOV.BR o PDF desta OS e baixou o documento assinado. O aplicativo não validará o certificado digital. Deseja selecionar o arquivo?'))return;saveOrderForm(false);if(window.Android?.importGovPdf)window.Android.importGovPdf();else toast('A importação e finalização do documento GOV.BR está disponível no APK Android.',true);};
  window.OSApp = {
    onPdfSaved(result){pendingPdf=false;$('#finish-pdf').disabled=false;try{const payload=typeof result==='string'?JSON.parse(result):result;if(payload.success){$('#pdf-status').textContent=`PDF salvo: ${payload.name||'Ordem de serviço'}`;toast('PDF gerado e salvo na pasta Downloads.');if(payload.finalize)finalizeOrder('PDF local');}else{const msg=payload.error||'Não foi possível gerar o PDF.';$('#pdf-status').textContent=msg;toast(msg,true);}}catch(e){toast('Falha ao processar retorno do PDF: '+e.message,true);}},
    onBackupSaved(result){const p=typeof result==='string'?JSON.parse(result):result;toast(p.success?'Backup salvo em Downloads/OS-Pro.':(p.error||'Falha ao salvar backup.'),!p.success);},
    onGovPdfImported(result){try{const p=typeof result==='string'?JSON.parse(result):result;if(p.success){$('#gov-status').textContent=`Documento importado sem alteração: ${p.name}. Valide a assinatura em validar.iti.gov.br.`;finalizeOrder('PDF assinado GOV.BR (validação externa pendente)');}else if(!p.cancelled)toast(p.error||'Erro ao importar documento.',true);}catch(e){toast(e.message,true);}}
  };
  function applyPrefs(){document.body.classList.toggle('hc',!!db.preferences.contrast);document.body.classList.toggle('large',!!db.preferences.large);}
  $('#contrast').onclick=()=>{db.preferences.contrast=!db.preferences.contrast;save();applyPrefs();};
  $('#large-text').onclick=()=>{db.preferences.large=!db.preferences.large;save();applyPrefs();};
  $('#settings-form').onsubmit=e=>{e.preventDefault();Object.assign(db.settings,formData(e.currentTarget));save();toast('Configurações salvas neste dispositivo.');};
  async function exportBackup(){const pictures={};for(const order of [db.current,...db.orders])for(const p of order.photos||[]){if(!pictures[p.id])try{pictures[p.id]=await photoOp('get',p.id);}catch{}}const backup={format:'ospro-backup-v1',exportedAt:now(),db:clone(db),pictures};const serialized=JSON.stringify(backup);if(window.Android?.saveBackup){window.Android.saveBackup(serialized);return;}const blob=new Blob([serialized],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`OSPro-backup-${dateInput()}.json`;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);toast('Backup JSON exportado.');}
  $('#backup').onclick=()=>exportBackup().catch(e=>toast('Erro no backup: '+e.message,true));
  $('#restore-input').onchange=async e=>{const file=e.target.files?.[0];if(!file)return;try{const back=JSON.parse(await file.text());if(back.format!=='ospro-backup-v1'||!back.db?.current||!Array.isArray(back.db.clients))throw Error('Backup incompatível.');if(!confirm('Substituir TODOS os dados locais por este backup?'))return;for(const [id,img] of Object.entries(back.pictures||{}))await photoOp('put',id,img);db=back.db;save();setForm($('#settings-form'),db.settings);syncOrderForm();renderAll();applyPrefs();toast('Backup restaurado.');}catch(err){toast(err.message||'Falha ao restaurar backup.',true);}finally{e.target.value='';}};
  function renderAll(){updateSelections();renderClients();renderUsers();renderFinance();renderDashboard();renderRemote();}
  // Autosave draft on input/change; signature and images are independent.
  let autosaveTimer;
  $('#os-form').addEventListener('input',()=>{clearTimeout(autosaveTimer);autosaveTimer=setTimeout(()=>saveOrderForm(false),500);});
  $('#os-form').addEventListener('change',()=>saveOrderForm(false));
  $('#finance-form').elements.namedItem('data').value=dateInput();
  setForm($('#settings-form'),db.settings);syncOrderForm();renderAll();applyPrefs();
  $('#clock').textContent=new Date().toLocaleDateString('pt-BR',{dateStyle:'medium'});
  // Expose a diagnostic status to basic test tooling, not private data.
  window.OSProVersion = '1.1.0';
})();
