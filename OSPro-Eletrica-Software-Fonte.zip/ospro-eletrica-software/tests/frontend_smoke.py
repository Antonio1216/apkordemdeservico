import subprocess,time
from pathlib import Path
from playwright.sync_api import sync_playwright
assets=Path(__file__).resolve().parents[1]/'app/src/main/assets'
port=18777
server=subprocess.Popen(['python','-m','http.server',str(port),'--bind','127.0.0.1'],cwd=assets,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
try:
    time.sleep(.3)
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
        context=browser.new_context(viewport={'width':400,'height':890},permissions=['geolocation'],geolocation={'latitude':-3.72,'longitude':-38.53})
        page=context.new_page()
        errors=[]
        page.on('pageerror',lambda e: errors.append(str(e)))
        page.goto(f'http://127.0.0.1:{port}/')
        assert page.locator('h1').first.inner_text()=='Visão geral'
        page.get_by_role('button',name='♙ Clientes').click()
        page.locator('#client-form [name=nome]').fill('Empresa Alfa')
        page.locator('#client-form [name=telefone]').fill('85999999999')
        page.get_by_role('button',name='Salvar cliente').click()
        assert page.get_by_text('Empresa Alfa').count()>=1
        page.get_by_role('button',name='♧ Usuários').click()
        page.locator('#user-form [name=nome]').fill('Técnico João')
        page.get_by_role('button',name='Salvar usuário').click()
        page.get_by_role('button',name='▤ Ordens de serviço').click()
        page.locator('#os-client').select_option(label='Empresa Alfa')
        page.locator('#os-tech').select_option(label='Técnico João')
        page.locator('#os-form [name=titulo]').fill('Instalação de circuito')
        page.locator('#os-form [name=maoObra]').fill('150')
        page.locator('#os-form [name=custoMateriais]').fill('20')
        assert '170,00' in page.locator('#os-total').inner_text()
        page.get_by_role('button',name='Salvar rascunho da OS').click()
        page.get_by_role('button',name='✍ Assinaturas').click()
        assert page.locator('#save-sign').is_disabled()
        rect=page.locator('#signature-canvas').bounding_box()
        page.mouse.move(rect['x']+50,rect['y']+60)
        page.mouse.down()
        page.mouse.move(rect['x']+150,rect['y']+90,steps=9)
        page.mouse.up()
        assert page.locator('#save-sign').is_enabled()
        page.locator('#save-sign').click()
        page.wait_for_timeout(800)
        assert page.locator('#save-sign').is_disabled()
        assert page.locator('#clear-sign').is_enabled()
        assert 'Localização:' in page.locator('#sign-metadata').inner_text()
        page.locator('#clear-sign').click()
        assert page.locator('#save-sign').is_disabled()
        assert not errors,errors
        print('SMOKE FRONTEND OK: cadastro cliente, técnico, OS, valores, assinatura, botão salvar/limpar')
        browser.close()
finally:
    server.terminate()
    server.wait(timeout=5)
